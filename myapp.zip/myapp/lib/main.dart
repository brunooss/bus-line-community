  import 'dart:io';
  import 'package:flutter/material.dart';
  import 'package:splash_screen_view/SplashScreenView.dart';
  
  
  
  
  import 'package:myapp/src/pages/loginpage/page.dart';
  import 'package:teta_cms/teta_cms.dart';

  ///NOTE:
  ///if you have an error while running <flutter run> 
  ///run <flutter pub upgrade> and than <flutter run --no-sound-null-safety>
  void main() async {
    WidgetsFlutterBinding.ensureInitialized();
    await TetaCMS.initialize(
      token: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImJydW5vLm9zc0BvdXRsb29rLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJwcm9qZWN0cyI6WzExOTU5MCwxMTgzODMsMTI3MzU0XSwibmFtZSI6IkJydW5vIE9saXZlaXJhIiwiZW1pdHRlciI6IlRldGEtQXV0aCIsImlhdCI6MTY1NDQ2NzI1NiwiZXhwIjo0ODEwMjI3MjU2fQ.cizHCLf5DqEz61Ke_cs4TtMjky3Ce7Yh_1gVasv4C1U',
      prjId: 127354,
    );
    
    
    
    
    runApp(
      MyApp()
    );
  }
  class MyApp extends StatelessWidget {
    @override
    Widget build(BuildContext context) {
      return MaterialApp(
        title: 'Rede Social dos Busao',
        home: SplashScreenView(
          navigateRoute: PageLoginPage(),
          duration: 2200,
          imageSize: 80,
          imageSrc: 'assets/teta-app.png',
          text: '',
          textType: TextType.NormalText,
          textStyle: TextStyle(
            fontSize: 30.0,
          ),
          backgroundColor: Colors.black,
        ),
      );
    }
  }
  